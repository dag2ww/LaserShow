#ifndef CUBE_H
#define CUBE_H

#include "Laser.h"

extern Laser laser;

void rotateCube(int count);

#endif
