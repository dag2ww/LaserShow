# LaserProjector
An Arduino driven Laser Projector using real galvos.

Building the project is explained here:

http://www.instructables.com/id/Arduino-Laser-Show-With-Real-Galvos/

Have a look at this video to see the filmed laser show:

https://youtu.be/JCon-suqPEE