This is a java implementation for ILDA.
=================================== 

This library enables you to read and write ilda files.

More information about the ilda standard can be found at: http://www.laserist.org/index.htm